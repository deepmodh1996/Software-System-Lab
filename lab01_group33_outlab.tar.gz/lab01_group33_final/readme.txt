Team no 33
Team Name:Anonymous
Team Member:
(Deep Modh,140050002) (Kapil Vaidya,140050006) (Mohit Vyas,140050015)

Honour Code:

I(Deep Modh) pledge on my honour that I have not given or received any unauthorized assistance on this assignment or any previous task.

I(Kapil Vaidya) pledge on my honour that I have not given or received any unauthorized assistance on this assignment or any previous task.

I(Mohit Vyas) pledge on my honour that I have not given or received any unauthorized assistance on this assignment or any previous task.

Relative Percentage:

Deep Modh=100%
Kapil Vaidya=100%
Mohit Vyas=100%

Citation:
https://www.gnu.org/software/octave/doc/interpreter/
http://stackoverflow.com/questions/22908570/eigenvalues-in-octave-with-eig
wikipedia.org


Extra Work Description:-
1.)Null space finder:- it calculates exact null space of a matrix by representing its elements as a pair of
   numerator and denominator so that we do not get floating point error while calculations. (this code assumes that input matrix has null
   space of dimension one only). [run nullspace_test.m to test the function in nullspace.m]

2.)Optimised root finder:- it uses binary search to optimise the code for finding roots for  part-1 of problem.
   (initially we planned to use it in function but we were not sure about no. of roots
    if no. of roots is known it calculates roots in an optimized manner )

3) pagerank without eig:- we do repeated multiplication of until it becomes stable.
   condition of stability is that norm(normalized(A*P)-P)<epsilon .

NOTE: Pleae execute all .mfiles in a folder to execute the code