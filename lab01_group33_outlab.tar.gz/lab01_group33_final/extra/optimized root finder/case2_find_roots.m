[x,y] = case2_code(3,3,10);
disp(x);
disp(y);
