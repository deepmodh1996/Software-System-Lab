function x = abs (a)

%calculates absolute value of a

  if(a>0)
     x=a;
  else
    x=(-1)*a;
  endif
  
  return;
endfunction