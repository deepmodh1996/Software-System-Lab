import java.awt.*;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class BasicGui {

	private JFrame mainFrame;
	private JLabel headerLabel;
	private JLabel statusLabel;
	private JPanel controlPanel;

	public BasicGui(){
		prepareGUI();
	}

	public static void main(String[] args){
		BasicGui bg = new BasicGui();
	
	}

	private void prepareGUI(){
		
		mainFrame = new JFrame("Java SWING Examples");
		mainFrame.setSize(400,400);
		mainFrame.setLayout(new GridLayout(3, 1));
		headerLabel = new JLabel("",JLabel.CENTER);
		statusLabel = new JLabel("",JLabel.CENTER);        

		controlPanel = new JPanel(new BorderLayout());
		
		statusLabel.setSize(350,100);
		mainFrame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent windowEvent){
				System.exit(0);
			}        
		});    

		
		
		headerLabel.setText("I am a basic GUI!!"); 
		mainFrame.add(headerLabel);
		mainFrame.add(controlPanel);
		mainFrame.add(statusLabel);
	//	mainFrame.setVisible(true); 
		
		//JFrame newframe=new JFrame("input");
		mainFrame.setLayout(new FlowLayout());
	//	newframe.setSize(200,100);
		
	/*	/////input
		final JTextField tf = new JTextField(20);
		tf.setVisible(true);
		 JButton loginButton = new JButton("Login");
	      loginButton.addActionListener(new ActionListener() {
	         public void actionPerformed(ActionEvent e) {     
	            String data =  tf.getText(); 
	            headerLabel.setText(data);        
	         }
	      }); 
	  
	      
		newframe.add(tf);
		//newframe.add(loginButton);
		 * 
		 */
		//newframe.setVisible(true); 
		
	final	JFrame frame = new JFrame("Java swing examples");
	frame.setSize(400, 400);
	frame.setVisible(true);
		  JButton button = new JButton("Red");
		  JButton button1 = new JButton("Blue");
		  JButton button2 = new JButton("Yellow");
		  JButton button3 = new JButton("Close");
		  
		 final String str1 = JOptionPane.showInputDialog(null, "What's Your Name?", 
					"Input", 1);
		 if(str1 == null){
		//  JOptionPane.showMessageDialog(null, "You entered the text : " , 
			//"Roseindia.net", 1);
System.out.println("So you want to cancel out it seems, hence be it!!");
			  frame.setVisible(false);frame.dispose();return ;
		 }
		 else
		 {
			 System.out.println("The user's name is '"+str1+"'.");
		 }
		  button.addActionListener(new ActionListener(){
		  public void actionPerformed(ActionEvent ae){
		  JOptionPane.showMessageDialog(null,"Hey "+ str1+ " !!It seems your favourite colour is Red!! :p ", 
		"Message", 1);
		 
		  }
		  });
		  
		  button1.addActionListener(new ActionListener(){
			  public void actionPerformed(ActionEvent ae){
			  JOptionPane.showMessageDialog(null, "Hey "+ str1+ " !!It seems your favourite colour is Blue!! :p ", 
						"Message", 1);
			  }
			  });
		  button2.addActionListener(new ActionListener(){
			  public void actionPerformed(ActionEvent ae){
			  JOptionPane.showMessageDialog(null,"Hey "+ str1+ " !!It seems your favourite colour is Yellow!! :p ", 
						"Message", 1);
			  }
			  });
		  button3.addActionListener(new ActionListener(){
			  public void actionPerformed(ActionEvent ae){
			  JOptionPane.showMessageDialog(null,"Hey "+ str1+ " !!Good Bye!! ", 
						"Message", 1);
			  frame.setVisible(false);frame.dispose();
			  }
			  });
		  
		  JPanel panel = new JPanel();
		// frame.add(headerLabel);
		 headerLabel.setText("                 " +
		 		"What  is  your  favourate  colour ?                       "); 
		 panel.add(headerLabel);
		  panel.add(button);
		  panel.add(button1);
		  panel.add(button2);
		  panel.add(button3);
		 
		  frame.add(panel);
		 // headerLabel.setText("What is your favourate colour"); 
		 
		  
		  frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		  frame.setVisible(true);
		
		
	}
}